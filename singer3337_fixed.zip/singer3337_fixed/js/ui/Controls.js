
export function setupControls(scene){
  const bar = document.createElement('footer');
  bar.className = 'control-bar';

  const btn = document.createElement('button');
  btn.className = 'control-btn';
  btn.textContent = 'Reset View';

  btn.onclick = () => scene.resetView();

  bar.appendChild(btn);

  document.getElementById('app').appendChild(bar);
}
