
export function renderInstructorPanel(lessons, controller){
  const list = document.getElementById('lesson-list');

  lessons.forEach((lesson, index) => {
    const item = document.createElement('div');
    item.className = 'lesson-item';
    item.innerHTML = `<strong>${lesson.title}</strong>`;
    item.onclick = () => controller.select(index);
    list.appendChild(item);
  });

  controller.select(0);
}
