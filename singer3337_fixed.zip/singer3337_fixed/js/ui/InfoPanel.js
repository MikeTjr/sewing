
export function renderInfoPanel(){
  const panel = document.createElement('aside');
  panel.className = 'panel panel-right';

  panel.innerHTML = `
    <div class="info-card">
      <div class="mono-label">Machine Status</div>
      <h3>Singer 3337 Ready</h3>
      <p>3D explorer initialized successfully.</p>
    </div>

    <div class="info-card">
      <div class="mono-label">Current Focus</div>
      <p>Interactive machine orientation and lesson navigation.</p>
    </div>
  `;

  document.querySelector('.app-main').appendChild(panel);
}
