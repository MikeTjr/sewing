
export class LessonController{
  constructor(lessons){
    this.lessons = lessons;
    this.current = 0;
  }

  select(index){
    this.current = index;

    const lesson = this.lessons[index];

    document.getElementById('dialogue-text').textContent = lesson.dialogue;
    document.getElementById('breadcrumb-title').textContent = lesson.title;
    document.getElementById('header-progress-label').textContent =
      `${index + 1} / ${this.lessons.length}`;

    document.getElementById('header-progress').style.width =
      `${((index+1)/this.lessons.length)*100}%`;
  }
}
