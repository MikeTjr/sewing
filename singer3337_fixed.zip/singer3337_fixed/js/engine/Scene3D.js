
export class Scene3D {
  constructor(canvasId){
    const canvas = document.getElementById(canvasId);

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x16151a);

    this.camera = new THREE.PerspectiveCamera(
      45,
      canvas.clientWidth / canvas.clientHeight,
      0.1,
      1000
    );

    this.camera.position.set(0, 2, 6);

    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias:true
    });

    this.renderer.setPixelRatio(window.devicePixelRatio);
    this.renderer.setSize(canvas.clientWidth, canvas.clientHeight);

    this.controls = new THREE.OrbitControls(this.camera, this.renderer.domElement);
    this.controls.enableDamping = true;

    const hemi = new THREE.HemisphereLight(0xffffff, 0x222222, 1.4);
    this.scene.add(hemi);

    const dir = new THREE.DirectionalLight(0xffffff, 1.1);
    dir.position.set(4,5,3);
    this.scene.add(dir);

    this.buildMachine();

    window.addEventListener('resize', () => this.resize());
    this.animate();
  }

  buildMachine(){
    const bodyMat = new THREE.MeshStandardMaterial({color:0xf2ede3});
    const aquaMat = new THREE.MeshStandardMaterial({color:0x4ecdc4});

    const body = new THREE.Mesh(
      new THREE.BoxGeometry(3.6,1.6,1.4),
      bodyMat
    );
    body.position.y = 1;
    this.scene.add(body);

    const arm = new THREE.Mesh(
      new THREE.BoxGeometry(2.2,0.5,1.2),
      bodyMat
    );
    arm.position.set(0.6,2,0);
    this.scene.add(arm);

    const accent = new THREE.Mesh(
      new THREE.BoxGeometry(1.1,0.35,1.41),
      aquaMat
    );
    accent.position.set(-0.8,1.1,0);
    this.scene.add(accent);

    const wheel = new THREE.Mesh(
      new THREE.TorusGeometry(0.42,0.09,16,100),
      new THREE.MeshStandardMaterial({color:0xc8cdd4})
    );
    wheel.rotation.y = Math.PI / 2;
    wheel.position.set(2,1.3,0);
    this.scene.add(wheel);

    const base = new THREE.Mesh(
      new THREE.BoxGeometry(5,0.35,2.2),
      new THREE.MeshStandardMaterial({color:0x2a2420})
    );
    base.position.y = 0;
    this.scene.add(base);
  }

  resize(){
    const canvas = this.renderer.domElement;
    this.camera.aspect = canvas.clientWidth / canvas.clientHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(canvas.clientWidth, canvas.clientHeight);
  }

  animate(){
    requestAnimationFrame(() => this.animate());
    this.controls.update();
    this.renderer.render(this.scene, this.camera);
  }

  resetView(){
    this.camera.position.set(0,2,6);
  }
}
